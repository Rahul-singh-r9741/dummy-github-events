package com.sa.springbootrestdemo.exception;

public class GitHubAPIException extends RuntimeException {
	public GitHubAPIException(String message, Throwable cause) {
		super(message, cause);
	}

}
