package com.sa.springbootrestdemo.model;

import java.util.Date;

public class GitHubCommit {
    private String message;
    private String authorName;
    private Date commitDate;
    // add more instance variables as needed

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Date getCommitDate() {
        return commitDate;
    }

    public void setCommitDate(Date commitDate) {
        this.commitDate = commitDate;
    }

    // add more getter and setter methods as needed
}

