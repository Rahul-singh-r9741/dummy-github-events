package com.sa.springbootrestdemo.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sa.springbootrestdemo.model.GitHubEvent;

@RestController
public class GitHubWebhookController {
	private static final Logger log = LoggerFactory.getLogger(GitHubWebhookController.class);

    @PostMapping("/webhook")
    public ResponseEntity<?> handleWebhook(@RequestBody String payload, @RequestHeader("X-GitHub-Event") String eventType) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            GitHubEvent event = objectMapper.readValue(payload, GitHubEvent.class);
            // You can use eventType to differentiate between push, pull_request, and merge events
            // Log the event details
            log.info("Received {} event from GitHub for repository {} with commit message: {}", eventType, event.getRepository().getName(), event.getHeadCommit().getMessage());
            return ResponseEntity.ok().build();
        } catch (IOException e) {
            log.error("Error while processing webhook payload: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }
}
