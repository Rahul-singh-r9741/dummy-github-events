package com.sa.springbootrestdemo.repository;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sa.springbootrestdemo.model.GitHubCommit;

public class GitHubRepository {
    
    @JsonProperty("name")
    private String name;
    
    public String getName() {
        return name;
    }
    public List<GitHubCommit> getCommits(String owner, String repo) {
        String url = String.format("https://api.github.com/repos/%s/%s/commits", owner, repo);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer YOUR_GITHUB_TOKEN");

        HttpEntity<String> entity = new HttpEntity<String>("", headers);

        ResponseEntity<GitHubCommit[]> response = new RestTemplate().exchange(
                url,
                HttpMethod.GET,
                entity,
                GitHubCommit[].class
        );

        GitHubCommit[] commitsArray = response.getBody();
        return Arrays.asList(commitsArray);
    }

    }


