package com.sa.springbootrestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebHookApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebHookApplication.class, args);
	}

}
