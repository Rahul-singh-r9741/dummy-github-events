package com.sa.springbootrestdemo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sa.springbootrestdemo.repository.GitHubRepository;

public class GitHubEvent {
    
    @JsonProperty("repository")
    private GitHubRepository repository;
    
    @JsonProperty("head_commit")
    private GitHubCommit headCommit;
    
    public GitHubRepository getRepository() {
        return repository;
    }
    
    public GitHubCommit getHeadCommit() {
        return headCommit;
    }
}

