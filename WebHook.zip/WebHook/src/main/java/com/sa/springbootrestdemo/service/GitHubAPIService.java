package com.sa.springbootrestdemo.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.sa.springbootrestdemo.exception.GitHubAPIException;
import com.sa.springbootrestdemo.model.GitHubCommit;


@Service
public class GitHubAPIService {

    private RestTemplate restTemplate;

    public GitHubAPIService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<GitHubCommit> getCommits(String owner, String repo) {
        try {
            String url = "https://api.github.com/repos/" + owner + "/" + repo + "/commits";
            GitHubCommit[] response = restTemplate.getForObject(url, GitHubCommit[].class);
            return List.of(response);
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                throw new GitHubAPIException("Repository not found", e);
            } else {
                throw new GitHubAPIException("Error while fetching commits from GitHub API", e);
            }
        } catch (Exception e) {
            throw new GitHubAPIException("Unexpected error occurred while fetching commits from GitHub API", e);
        }
    }
}
